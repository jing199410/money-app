輕帳 PWA 使用與部署教學

一、本機測試
1. 解壓縮此資料夾。
2. 直接打開 index.html 可先測試基本功能。
3. 若要測試「加入主畫面 / 離線功能」，請部署到 GitHub Pages 後再測。

二、部署到 GitHub Pages
1. 到 GitHub 建立新 Repository，例如：money-pwa。
2. 點 Add file → Upload files。
3. 將整個資料夾內的檔案上傳：index.html、style.css、app.js、manifest.json、sw.js、icons 資料夾。
4. 按 Commit changes。
5. 進入 Settings → Pages。
6. Source 選 Deploy from a branch。
7. Branch 選 main，資料夾選 /root。
8. 按 Save。
9. 等 GitHub 產生網址後，用手機開啟。

三、手機加入主畫面
iPhone Safari：開網址 → 分享按鈕 → 加入主畫面。
Android Chrome：開網址 → 右上角 ⋮ → 安裝應用程式 / 加入主畫面。

四、重要提醒
1. 目前資料存在手機／瀏覽器本機，不經過 GAS。
2. 刪除瀏覽器資料、換手機、換瀏覽器，資料可能不會跟著走。
3. 這版可用「匯出」下載 CSV 備份。
4. 下一版可升級 Firebase，做到雲端同步與登入。
